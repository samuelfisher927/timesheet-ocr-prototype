# timesheet-ocr-prototype
This Repo is a prototype OCR that utilizes fine-tuned layout and OCR transformer models to read in handwritten timesheets and export them into csv files our consultants can utilize
